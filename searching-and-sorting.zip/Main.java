import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
public static void main(String[] args) {
  	Scanner in = new Scanner(System.in);
		SearchAndSort search = new SearchAndSort(); 
		int target = 0; 
		
		System.out.println("What algorithm would you like to execute? "); 
		String algorithm = in.nextLine().toLowerCase(); 
		
		if (algorithm.equals("linear") || algorithm.equals("binary")) {
			System.out.println("What would the target value be? ");
			target = in.nextInt();
			in.nextLine(); 
		}
		
		else if (algorithm.equals("quit")) {
			System.exit(0);
		}
		
		System.out.println("What type of data? ");
		String datatype = in.nextLine().toLowerCase(); 
		
		System.out.println("How is it stored? ");
		String storage = in.nextLine().toLowerCase(); 
		
		System.out.println("Enter the data separated by commas: ");
		String enteredData = in.nextLine(); 
		
		/**
		 * list1 for integer array
		 * list3 for integer arraylist
		 * list4 for string arraylist
		 */
		
		if (storage.equals("array")) {
			if (datatype.equals("integer")) {
				String[] list1 = enteredData.split(",");
				int ints[] = new int[list1.length]; 
				for (int i = 0; i < list1.length; i++) 
		            ints[i] = Integer.parseInt(list1[i]);
				System.out.println(Arrays.toString(ints));
				
				switch (algorithm) {
				case "bubble":
					System.out.println("Bubble Sort: " + Arrays.toString(search.bubble(ints)));
					break; 
				case "selection":
					System.out.println("Selection Sort: " + Arrays.toString(search.selection(ints)));
					break;
				case "insertion": 
					System.out.println("Insertion Sort: " + Arrays.toString(search.insertion(ints)));
					break;
				case "merge":
					System.out.println("Merge Sort: " + Arrays.toString(search.merge(ints)));
					break;
				case "linear":
					System.out.println("Linear Search: " + search.linear(ints, target));
					break;
				case "binary": 
					System.out.println("Binary Search: " + search.binary(ints, target));
					break; 
				}
			}
			else if (datatype.equals("string")) {
				String[] strings = enteredData.split(",");
				System.out.println(Arrays.toString(strings));
				
				switch (algorithm) {
				case "bubble":
					System.out.println("Bubble Sort: " + Arrays.toString(search.bubble(strings)));
					break; 
				case "selection":
					System.out.println("Selection Sort: " + Arrays.toString(search.selection(strings)));
					break;
				case "insertion": 
					System.out.println("Insertion Sort: " + Arrays.toString(search.insertion(strings)));
					break;
				case "merge":
					System.out.println("Merge Sort: " + Arrays.toString(search.merge(strings)));
					break;
				case "linear":
					System.out.println("Linear Search: " + search.linear(strings, target));
					break;
				case "binary": 
					System.out.println("Binary Search: " + search.binary(strings, target));
					break; 
				}
			}
		}
		else if (storage.equals("arraylist")) {
			if (datatype.equals("integer")) {
				String[] strings = enteredData.split(",");
				ArrayList<Integer> list3 = new ArrayList<Integer>(strings.length);
				for (int i = 0; i < strings.length; i++) {
					list3.add(Integer.parseInt(strings[i])); 
				}
				System.out.println(Arrays.toString(strings));
				
				switch (algorithm) {
				case "bubble":
					System.out.println("Bubble Sort: " + search.bubble(list3));
					break; 
				case "selection":
					System.out.println("Selection Sort: " + search.selection(list3));
					break;
				case "insertion": 
					System.out.println("Insertion Sort: " + search.insertion(list3));
					break;
				case "merge":
					System.out.println("Merge Sort: " + search.merge(list3));
					break;
				case "linear":
					System.out.println("Linear Search: " + search.linear(list3, target));
					break;
				case "binary": 
					System.out.println("Binary Search: " + search.binary(list3, target));
					break; 
				}

			}
			else if (datatype.equals("string")) {
				String[] strings = enteredData.split(",");
				ArrayList<String> list4 = new ArrayList<String>(strings.length); 
				for(int i = 0; i < strings.length; i++) {
					list4.add(strings[i]);
				}
				System.out.println(Arrays.toString(strings)); 
				
				switch (algorithm) {
				case "bubble":
					System.out.println("Bubble Sort: " + search.bubble(false, list4));
					break; 
				case "selection":
					System.out.println("Selection Sort: " + search.selection(false, list4));
					break;
				case "insertion": 
					System.out.println("Insertion Sort: " + search.insertion(false, list4));
					break;
				case "merge":
					System.out.println("Merge Sort: " + search.merge(false, list4));
					break;
				case "linear":
					System.out.println("Linear Search: " + search.linear(false, list4, target));
					break;
				case "binary": 
					System.out.println("Binary Search: " + search.binary(false, list4, target));
					break; 
				}
			}
		}
	}
}
	